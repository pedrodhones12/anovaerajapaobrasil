import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Book,
  FileText,
  Image as ImageIcon,
  Download,
  ExternalLink,
  Video,
  Newspaper,
  GraduationCap,
  BarChart3,
  Globe
} from "lucide-react";
import { motion } from "framer-motion";

const ResourceCard = ({ icon: Icon, title, description, type, action, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.5 }}
  >
    <Card className="bg-white/5 backdrop-blur-sm border border-white/10 h-full group hover:border-white/20 transition-all duration-300">
      <CardHeader>
        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
          <Icon className="w-7 h-7 text-white" />
        </div>
        <Badge className="w-fit mb-2" variant="secondary">{type}</Badge>
        <CardTitle className="text-white text-lg group-hover:text-blue-400 transition-colors">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-gray-300 text-sm leading-relaxed">{description}</p>
        <Button 
          variant="outline" 
          className="w-full group-hover:bg-white/10"
          onClick={action}
        >
          {type === "Download" ? <Download className="w-4 h-4 mr-2" /> : <ExternalLink className="w-4 h-4 mr-2" />}
          {type === "Download" ? "Baixar Material" : "Acessar"}
        </Button>
      </CardContent>
    </Card>
  </motion.div>
);

const InfographicCard = ({ title, data, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ delay, duration: 0.5 }}
  >
    <Card className={`bg-gradient-to-br ${color} border-none shadow-xl`}>
      <CardContent className="p-6">
        <h3 className="text-white font-bold text-lg mb-4">{title}</h3>
        <div className="space-y-3">
          {data.map((item, idx) => (
            <div key={idx} className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
              <div className="flex justify-between items-center">
                <span className="text-white/90 text-sm">{item.label}</span>
                <span className="text-white font-bold text-lg">{item.value}</span>
              </div>
              {item.trend && (
                <p className="text-white/70 text-xs mt-1">{item.trend}</p>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

export default function Recursos() {
  const handleDownload = (filename, content) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadInfographic = () => {
    const content = `
    ====================================
    JAPÃO: 1945-2025 - INFOGRÁFICO
    ====================================
    
    📊 CRESCIMENTO DO PIB
    1945-1955: Reconstrução (crescimento variável)
    1955-1975: Milagre Econômico (~10% ao ano)
    1975-1990: Consolidação (4-6% ao ano)
    1990-2010: Estagnação (0.5-1.5% ao ano)
    2010-2025: Estabilização (1-2% ao ano)
    
    🔬 INVESTIMENTO EM P&D
    1960: 1.0% do PIB
    1980: 2.0% do PIB
    2000: 3.0% do PIB
    2025: 3.5% do PIB
    
    🏆 CONQUISTAS PRINCIPAIS
    • 1968: 2ª maior economia mundial
    • 1980: Líder em robótica industrial
    • 2010: 3ª maior economia (ultrapassado pela China)
    • 2025: Líder em IA e robótica avançada
    
    🇧🇷 COMPARAÇÃO BRASIL × JAPÃO
    P&D: Brasil 1.2% vs Japão 3.5%
    Patentes: Brasil 35/milhão vs Japão 3.500/milhão
    Educação: Brasil 58/100 vs Japão 92/100
    
    💡 LIÇÕES PARA O BRASIL
    1. Investir pesadamente em educação técnica
    2. Aumentar P&D para 2-3% do PIB
    3. Criar políticas de longo prazo
    4. Integrar universidades e empresas
    5. Cultura de inovação contínua
    `;
    handleDownload('infografico-japao-brasil.txt', content);
  };

  const downloadTimeline = () => {
    const content = `
    ====================================
    LINHA DO TEMPO: JAPÃO 1945-2025
    ====================================
    
    📅 1945-1955: RECONSTRUÇÃO
    • 1945: Bombas atômicas devastam Hiroshima e Nagasaki
    • 1947: Nova constituição democrática
    • 1950: Guerra da Coreia impulsiona indústria japonesa
    • 1952: Fim da ocupação aliada
    
    📅 1955-1975: MILAGRE ECONÔMICO
    • 1960: Plano de duplicação da renda nacional
    • 1964: Olimpíadas de Tóquio + Shinkansen inaugurado
    • 1968: Japão se torna 2ª maior economia mundial
    • 1973: Crise do petróleo - adaptação com eficiência
    
    📅 1975-1990: ERA DA INOVAÇÃO
    • 1979: Sony lança Walkman revolucionário
    • 1980: Japão domina 60% mercado global de robótica
    • 1985: Nintendo conquista mercado de videogames
    • 1989: Bolha econômica atinge pico histórico
    
    📅 1990-2010: DÉCADA PERDIDA
    • 1991: Estouro da bolha imobiliária
    • 1997: Crise financeira asiática
    • 2001: Reformas estruturais e foco em exportação
    • 2008: Crise global impacta economia
    
    📅 2010-2025: LÍDER EM IA E ROBÓTICA
    • 2011: Terremoto, tsunami e Fukushima
    • 2015: Políticas Abenomics de estímulo
    • 2020: Olimpíadas tecnológicas (robôs, 5G, IA)
    • 2025: Líder em robôs de cuidado e cidades inteligentes
    `;
    handleDownload('linha-do-tempo-japao.txt', content);
  };

  const downloadComparison = () => {
    const content = `
    ====================================
    COMPARAÇÃO BRASIL × JAPÃO (2025)
    ====================================
    
    📊 INDICADORES ECONÔMICOS
    
    PIB per capita:
    • Brasil: $9.000
    • Japão: $39.000
    
    Ranking de Inovação:
    • Brasil: #57
    • Japão: #13
    
    População:
    • Brasil: 215 milhões
    • Japão: 125 milhões
    
    🔬 INVESTIMENTO EM P&D
    • Brasil: 1.2% do PIB
    • Japão: 3.5% do PIB
    
    📚 EDUCAÇÃO
    • Brasil: Índice 58/100
    • Japão: Índice 92/100
    
    🏭 INFRAESTRUTURA
    • Brasil: Índice 62/100
    • Japão: Índice 95/100
    
    💼 AMBIENTE DE NEGÓCIOS
    • Brasil: Índice 55/100
    • Japão: Índice 88/100
    
    🏆 PATENTES
    • Brasil: 35 por milhão de habitantes
    • Japão: 3.500 por milhão de habitantes
    
    ✅ JAPÃO - PONTOS FORTES:
    1. P&D líder mundial (3.5% do PIB)
    2. Sistema educacional de elite
    3. Cultura de inovação (Kaizen)
    4. Empresas globalmente competitivas
    
    ⚠️ BRASIL - DESAFIOS:
    1. Baixo investimento em P&D (1.2%)
    2. Desigualdade educacional
    3. Burocracia excessiva
    4. Falta de integração universidade-empresa
    
    💡 OPORTUNIDADES PARA O BRASIL:
    • Aumentar P&D para 2-3% do PIB até 2030
    • Reformar sistema educacional
    • Incentivar startups e inovação
    • Criar políticas de longo prazo
    • Aprender com modelo japonês de crescimento endógeno
    `;
    handleDownload('comparacao-brasil-japao.txt', content);
  };

  return (
    <div className="min-h-screen p-6 md:p-10">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <Badge className="bg-amber-600 text-white mb-4">Materiais Educativos</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Recursos
          </h1>
          <p className="text-gray-300 text-lg leading-relaxed max-w-4xl">
            Acesse infográficos, documentos, gráficos e materiais complementares para download 
            ou visualização online.
          </p>
        </motion.div>

        {/* Quick Stats Infographics */}
        <div className="grid md:grid-cols-3 gap-6">
          <InfographicCard
            title="🇯🇵 Japão em Números"
            color="from-red-600 to-red-800"
            delay={0.2}
            data={[
              { label: "Ranking Global", value: "#13", trend: "Inovação" },
              { label: "P&D / PIB", value: "3.5%", trend: "Líder mundial" },
              { label: "Patentes", value: "3.5k/M", trend: "Por milhão hab." }
            ]}
          />
          <InfographicCard
            title="🇧🇷 Brasil em Números"
            color="from-emerald-600 to-emerald-800"
            delay={0.3}
            data={[
              { label: "Ranking Global", value: "#57", trend: "Inovação" },
              { label: "P&D / PIB", value: "1.2%", trend: "Abaixo da média" },
              { label: "Patentes", value: "35/M", trend: "Por milhão hab." }
            ]}
          />
          <InfographicCard
            title="📈 Crescimento Histórico"
            color="from-blue-600 to-indigo-800"
            delay={0.4}
            data={[
              { label: "1955-1975", value: "10%", trend: "PIB/ano (Japão)" },
              { label: "1990-2010", value: "1%", trend: "Década perdida" },
              { label: "2010-2025", value: "2%", trend: "Estabilização" }
            ]}
          />
        </div>

        {/* Downloadable Resources */}
        <div>
          <h2 className="text-3xl font-bold text-white mb-6">Materiais para Download</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ResourceCard
              icon={ImageIcon}
              title="Infográfico Completo"
              description="Visualização dos principais dados e indicadores sobre Japão e Brasil em formato resumido."
              type="Download"
              action={downloadInfographic}
              color="from-purple-600 to-purple-800"
              delay={0.5}
            />
            <ResourceCard
              icon={FileText}
              title="Linha do Tempo"
              description="Cronologia detalhada dos eventos mais importantes do Japão de 1945 a 2025."
              type="Download"
              action={downloadTimeline}
              color="from-red-600 to-red-800"
              delay={0.6}
            />
            <ResourceCard
              icon={BarChart3}
              title="Análise Comparativa"
              description="Comparação completa entre Brasil e Japão em P&D, educação, inovação e produtividade."
              type="Download"
              action={downloadComparison}
              color="from-emerald-600 to-emerald-800"
              delay={0.7}
            />
          </div>
        </div>

        {/* External Resources */}
        <div>
          <h2 className="text-3xl font-bold text-white mb-6">Recursos Externos</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <ResourceCard
              icon={Book}
              title="Banco Mundial - Dados do Japão"
              description="Acesse estatísticas oficiais sobre crescimento, PIB, e indicadores socioeconômicos."
              type="Link"
              action={() => window.open('https://data.worldbank.org/country/japan', '_blank')}
              color="from-blue-600 to-blue-800"
              delay={0.8}
            />
            <ResourceCard
              icon={GraduationCap}
              title="OCDE - Educação e Inovação"
              description="Relatórios sobre políticas educacionais e investimento em pesquisa e desenvolvimento."
              type="Link"
              action={() => window.open('https://www.oecd.org/japan/', '_blank')}
              color="from-indigo-600 to-indigo-800"
              delay={0.9}
            />
            <ResourceCard
              icon={Newspaper}
              title="Artigos Acadêmicos"
              description="Google Scholar com pesquisas sobre crescimento endógeno e economia japonesa."
              type="Link"
              action={() => window.open('https://scholar.google.com/scholar?q=endogenous+growth+japan', '_blank')}
              color="from-amber-600 to-amber-800"
              delay={1.0}
            />
            <ResourceCard
              icon={Globe}
              title="JETRO - Investimento no Japão"
              description="Organização de comércio exterior com dados sobre negócios e tecnologia japonesa."
              type="Link"
              action={() => window.open('https://www.jetro.go.jp/en/', '_blank')}
              color="from-teal-600 to-teal-800"
              delay={1.1}
            />
          </div>
        </div>

        {/* Video Resources */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-r from-pink-900/40 to-purple-900/40 border border-pink-700/30 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-600 to-purple-600 flex items-center justify-center">
                  <Video className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="text-2xl text-white">Recursos em Vídeo</CardTitle>
                  <p className="text-gray-300 text-sm">Documentários e palestras recomendadas</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <h4 className="font-semibold text-white mb-2">📺 "Japan's Economic Miracle" - PBS Documentary</h4>
                  <p className="text-gray-300 text-sm mb-3">Documentário sobre a reconstrução japonesa pós-guerra.</p>
                  <Button variant="outline" size="sm" onClick={() => window.open('https://www.youtube.com/results?search_query=japan+economic+miracle', '_blank')}>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Buscar no YouTube
                  </Button>
                </div>
                <div className="bg-white/5 rounded-lg p-4">
                  <h4 className="font-semibold text-white mb-2">📺 TED Talks sobre Inovação e Crescimento Econômico</h4>
                  <p className="text-gray-300 text-sm mb-3">Palestras inspiradoras sobre tecnologia e desenvolvimento.</p>
                  <Button variant="outline" size="sm" onClick={() => window.open('https://www.ted.com/topics/innovation', '_blank')}>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver TED Talks
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-br from-red-600 to-amber-600 border-none shadow-2xl">
            <CardContent className="p-8 text-center">
              <h3 className="text-3xl font-bold text-white mb-4">
                Contribua com o Projeto
              </h3>
              <p className="text-white/90 text-lg mb-6">
                Tem sugestões de materiais ou recursos? Gostaria de colaborar com análises adicionais?
              </p>
              <Button size="lg" className="bg-white text-red-700 hover:bg-gray-100 font-bold">
                <Book className="w-5 h-5 mr-2" />
                Entre em Contato
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}