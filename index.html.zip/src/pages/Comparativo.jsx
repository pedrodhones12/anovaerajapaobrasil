import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp,
  TrendingDown,
  GraduationCap,
  Factory,
  Lightbulb,
  AlertTriangle,
  CheckCircle2,
  XCircle
} from "lucide-react";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

const comparisonData = [
  { metric: "Investimento P&D (% PIB)", japan: 3.5, brazil: 1.2 },
  { metric: "Patentes por milhão", japan: 3500, brazil: 35 },
  { metric: "Qualidade Educacional", japan: 92, brazil: 58 },
  { metric: "Infraestrutura", japan: 95, brazil: 62 },
  { metric: "Ambiente de Negócios", japan: 88, brazil: 55 }
];

const radarData = [
  { subject: 'Inovação', Japan: 95, Brasil: 42 },
  { subject: 'Educação', Japan: 92, Brasil: 58 },
  { subject: 'Infraestrutura', Japan: 95, Brasil: 62 },
  { subject: 'P&D', Japan: 98, Brasil: 35 },
  { subject: 'Tecnologia', Japan: 96, Brasil: 48 },
  { subject: 'Produtividade', Japan: 90, Brasil: 52 }
];

const ComparisonRow = ({ metric, japan, brazil, delay, isPercentage = false }) => {
  const japanPercent = isPercentage ? japan : (japan / Math.max(japan, brazil)) * 100;
  const brazilPercent = isPercentage ? brazil : (brazil / Math.max(japan, brazil)) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay, duration: 0.5 }}
      className="space-y-3"
    >
      <h4 className="font-semibold text-white">{metric}</h4>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-300">🇯🇵 Japão</span>
            <span className="font-bold text-red-400">{japan}{isPercentage ? '%' : ''}</span>
          </div>
          <Progress value={japanPercent} className="h-2 bg-white/10" />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-300">🇧🇷 Brasil</span>
            <span className="font-bold text-emerald-400">{brazil}{isPercentage ? '%' : ''}</span>
          </div>
          <Progress value={brazilPercent} className="h-2 bg-white/10" />
        </div>
      </div>
    </motion.div>
  );
};

const FactorCard = ({ country, icon: Icon, factors, isPositive, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.6 }}
  >
    <Card className={`bg-gradient-to-br ${isPositive ? 'from-emerald-900/40 to-teal-900/40 border-emerald-700/30' : 'from-red-900/40 to-orange-900/40 border-red-700/30'} backdrop-blur-sm`}>
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl ${isPositive ? 'bg-emerald-600' : 'bg-red-600'} flex items-center justify-center`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <CardTitle className="text-xl text-white">{country}</CardTitle>
            <p className="text-sm text-gray-300">{isPositive ? 'Pontos Fortes' : 'Desafios'}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {factors.map((factor, idx) => (
          <div key={idx} className="flex items-start gap-3">
            {isPositive ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            )}
            <div>
              <p className="text-white font-semibold text-sm">{factor.title}</p>
              <p className="text-gray-300 text-xs">{factor.description}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  </motion.div>
);

export default function Comparativo() {
  const japanStrengths = [
    { title: "P&D Líder Mundial", description: "3.5% do PIB investido em pesquisa e inovação" },
    { title: "Educação de Elite", description: "Sistema educacional entre os melhores globalmente" },
    { title: "Cultura de Inovação", description: "Kaizen e busca constante por excelência" },
    { title: "Empresas Inovadoras", description: "Toyota, Sony, Honda lideram mercados" }
  ];

  const brazilChallenges = [
    { title: "Baixo Investimento P&D", description: "Menos de 1.2% do PIB em pesquisa" },
    { title: "Desigualdade Educacional", description: "Sistema fragmentado e desigual" },
    { title: "Burocracia Excessiva", description: "Dificulta investimentos e inovação" },
    { title: "Falta de Integração", description: "Universidades e empresas desconectadas" }
  ];

  return (
    <div className="min-h-screen p-6 md:p-10">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <Badge className="bg-emerald-600 text-white mb-4">Análise Comparativa</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Brasil × Japão
          </h1>
          <p className="text-gray-300 text-lg leading-relaxed max-w-4xl">
            Uma comparação detalhada dos investimentos em inovação, educação e desenvolvimento 
            tecnológico entre as duas nações.
          </p>
        </motion.div>

        {/* Summary Cards */}
        <div className="grid md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <Card className="bg-gradient-to-br from-red-900/40 to-pink-900/40 border border-red-700/30 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="text-4xl">🇯🇵</div>
                  <div>
                    <CardTitle className="text-2xl text-white">Japão</CardTitle>
                    <p className="text-gray-300 text-sm">Líder em Inovação</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Ranking de Inovação</span>
                    <span className="text-2xl font-bold text-red-400">#13</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">PIB per capita</span>
                    <span className="text-2xl font-bold text-red-400">$39k</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">População</span>
                    <span className="text-xl font-bold text-red-400">125M</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <Card className="bg-gradient-to-br from-emerald-900/40 to-teal-900/40 border border-emerald-700/30 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="text-4xl">🇧🇷</div>
                  <div>
                    <CardTitle className="text-2xl text-white">Brasil</CardTitle>
                    <p className="text-gray-300 text-sm">Potencial Subutilizado</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Ranking de Inovação</span>
                    <span className="text-2xl font-bold text-emerald-400">#57</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">PIB per capita</span>
                    <span className="text-2xl font-bold text-emerald-400">$9k</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">População</span>
                    <span className="text-xl font-bold text-emerald-400">215M</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Radar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <Card className="bg-white/5 backdrop-blur-sm border border-white/10">
            <CardHeader>
              <CardTitle className="text-2xl text-white">
                Comparação Multidimensional
              </CardTitle>
              <p className="text-gray-300 text-sm">Pontuação em diferentes dimensões (0-100)</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="#4B5563" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#D1D5DB', fontSize: 12 }} />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#9CA3AF' }} />
                  <Radar name="Japão" dataKey="Japan" stroke="#EF4444" fill="#EF4444" fillOpacity={0.5} />
                  <Radar name="Brasil" dataKey="Brasil" stroke="#10B981" fill="#10B981" fillOpacity={0.5} />
                  <Legend wrapperStyle={{ color: '#fff' }} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151', borderRadius: '8px' }}
                    labelStyle={{ color: '#F3F4F6' }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Detailed Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Card className="bg-white/5 backdrop-blur-sm border border-white/10">
            <CardHeader>
              <CardTitle className="text-2xl text-white">
                Indicadores Detalhados
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
              <ComparisonRow metric="Investimento P&D (% PIB)" japan={3.5} brazil={1.2} delay={0.6} />
              <ComparisonRow metric="Patentes por milhão hab." japan={3500} brazil={35} delay={0.7} />
              <ComparisonRow metric="Qualidade Educacional" japan={92} brazil={58} delay={0.8} isPercentage />
              <ComparisonRow metric="Infraestrutura" japan={95} brazil={62} delay={0.9} isPercentage />
              <ComparisonRow metric="Ambiente de Negócios" japan={88} brazil={55} delay={1.0} isPercentage />
            </CardContent>
          </Card>
        </motion.div>

        {/* Strengths and Challenges */}
        <div className="grid md:grid-cols-2 gap-6">
          <FactorCard
            country="🇯🇵 Japão"
            icon={TrendingUp}
            factors={japanStrengths}
            isPositive={true}
            delay={1.1}
          />
          <FactorCard
            country="🇧🇷 Brasil"
            icon={AlertTriangle}
            factors={brazilChallenges}
            isPositive={false}
            delay={1.2}
          />
        </div>

        {/* Conclusion */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-r from-indigo-900/40 to-purple-900/40 border border-indigo-700/30 backdrop-blur-sm">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-3">
                <Lightbulb className="w-8 h-8 text-amber-400" />
                Conclusão
              </h3>
              <p className="text-gray-200 text-lg leading-relaxed mb-4">
                O Japão demonstra como o investimento contínuo em <span className="font-bold text-amber-400">educação, 
                pesquisa e inovação</span> pode transformar uma nação devastada em líder tecnológico global.
              </p>
              <p className="text-gray-200 text-lg leading-relaxed">
                O Brasil possui imenso potencial, mas precisa de <span className="font-bold text-emerald-400">políticas 
                de longo prazo</span>, maior investimento em P&D, reforma educacional e integração entre 
                universidades e empresas para desbloquear seu crescimento endógeno.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}