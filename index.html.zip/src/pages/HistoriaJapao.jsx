import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Calendar,
  TrendingUp,
  Factory,
  Cpu,
  Zap,
  Rocket,
  Building2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const timelineImages = {
  "1945-1955": "https://images.unsplash.com/photo-1513407030348-c983a97b98d8?w=600",
  "1955-1975": "https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=600",
  "1975-1990": "https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?w=600",
  "1990-2010": "https://images.unsplash.com/photo-1480796927426-f609979314bd?w=600",
  "2010-2025": "https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=600"
};

const timelineData = [
  {
    period: "1945-1955",
    title: "Reconstrução Pós-Guerra",
    icon: Building2,
    color: "from-gray-600 to-gray-800",
    events: [
      { year: "1945", title: "Bombas de Hiroshima e Nagasaki", description: "Devastação total. PIB reduzido drasticamente." },
      { year: "1947", title: "Nova Constituição", description: "Foco em democracia e pacifismo." },
      { year: "1950", title: "Guerra da Coreia", description: "Demanda por produtos japoneses impulsiona recuperação." },
      { year: "1952", title: "Fim da Ocupação", description: "Japão recupera soberania e foca em industrialização." }
    ],
    stats: { gdp: "Recuperação inicial", rd: "< 0.5%", sector: "Reconstrução básica" }
  },
  {
    period: "1955-1975",
    title: "Milagre Econômico",
    icon: Rocket,
    color: "from-amber-600 to-orange-700",
    events: [
      { year: "1960", title: "Plano de Duplicação da Renda", description: "Meta: dobrar PIB em 10 anos (alcançada em 7!)." },
      { year: "1964", title: "Olimpíadas de Tóquio", description: "Vitrine tecnológica: Shinkansen (trem-bala) inaugurado." },
      { year: "1968", title: "2ª Maior Economia", description: "Japão supera Alemanha e se torna segunda potência mundial." },
      { year: "1973", title: "Crise do Petróleo", description: "Japão se adapta com eficiência energética e carros econômicos." }
    ],
    stats: { gdp: "~10% ao ano", rd: "1.5%", sector: "Eletrônicos e automóveis" }
  },
  {
    period: "1975-1990",
    title: "Era da Inovação",
    icon: Cpu,
    color: "from-blue-600 to-indigo-700",
    events: [
      { year: "1979", title: "Walkman da Sony", description: "Revolução na música portátil." },
      { year: "1980", title: "Robôs Industriais", description: "Japão domina 60% do mercado global de robótica." },
      { year: "1985", title: "Nintendo NES", description: "Conquista mercado de videogames." },
      { year: "1989", title: "Bolha Econômica", description: "Bolha imobiliária e de ações atinge pico histórico." }
    ],
    stats: { gdp: "4-6% ao ano", rd: "2.5%", sector: "Eletrônicos e robótica" }
  },
  {
    period: "1990-2010",
    title: "Década Perdida e Adaptação",
    icon: TrendingUp,
    color: "from-purple-600 to-purple-800",
    events: [
      { year: "1991", title: "Estouro da Bolha", description: "Início de estagnação econômica prolongada." },
      { year: "1997", title: "Crise Asiática", description: "Japão enfrenta desafios regionais." },
      { year: "2001", title: "Reformas Estruturais", description: "Foco em exportações e manufatura de alta tecnologia." },
      { year: "2008", title: "Crise Global", description: "Impacto severo, mas recuperação com automação." }
    ],
    stats: { gdp: "0.5-1.5% ao ano", rd: "3.0%", sector: "Automação e precisão" }
  },
  {
    period: "2010-2025",
    title: "Líder em IA e Robótica",
    icon: Zap,
    color: "from-red-600 to-red-800",
    events: [
      { year: "2011", title: "Terremoto e Tsunami", description: "Desastre de Fukushima. Japão demonstra resiliência." },
      { year: "2015", title: "Abenomics", description: "Políticas agressivas de estímulo econômico." },
      { year: "2020", title: "Olimpíadas Tecnológicas", description: "Robôs assistentes, carros autônomos e 5G." },
      { year: "2025", title: "Era da IA", description: "Líder em robôs de cuidado para idosos e cidades inteligentes." }
    ],
    stats: { gdp: "1-2% ao ano", rd: "3.5%", sector: "IA, robótica e sustentabilidade" }
  }
];

const TimelineCard = ({ period, title, icon: Icon, color, events, stats, delay, imageUrl }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -30 }}
    transition={{ delay, duration: 0.6 }}
  >
    <Card className="bg-white/5 backdrop-blur-sm border border-white/10 overflow-hidden">
      {/* Animated Header Image */}
      <motion.div 
        className="relative h-48 overflow-hidden"
        whileHover={{ scale: 1.05 }}
        transition={{ duration: 0.5 }}
      >
        <motion.img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover"
          animate={{
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <Badge className={`bg-gradient-to-r ${color} text-white border-none px-4 py-1 mb-2`}>
            {period}
          </Badge>
          <h3 className="text-white font-bold text-xl">{title}</h3>
        </div>
        <motion.div 
          className={`absolute top-4 right-4 w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center`}
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        >
          <Icon className="w-6 h-6 text-white" />
        </motion.div>
      </motion.div>

      <CardContent className="space-y-6 p-6">
        <div className="space-y-3">
          {events.map((event, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: delay + 0.1 * (idx + 1), duration: 0.4 }}
              className="border-l-2 border-red-500 pl-4 py-2 hover:bg-white/5 rounded-r-lg transition-all"
            >
              <div className="flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4 text-red-400" />
                <span className="font-bold text-red-400">{event.year}</span>
              </div>
              <h4 className="font-semibold text-white text-sm mb-1">{event.title}</h4>
              <p className="text-gray-300 text-xs leading-relaxed">{event.description}</p>
            </motion.div>
          ))}
        </div>

        <div className="bg-white/5 rounded-lg p-4 space-y-2">
          <h5 className="font-semibold text-white text-sm mb-3">Indicadores do Período</h5>
          <div className="grid grid-cols-3 gap-3 text-center">
            <motion.div
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <p className="text-xs text-gray-400 mb-1">Crescimento PIB</p>
              <p className="text-sm font-bold text-emerald-400">{stats.gdp}</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <p className="text-xs text-gray-400 mb-1">P&D / PIB</p>
              <p className="text-sm font-bold text-blue-400">{stats.rd}</p>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.1 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <p className="text-xs text-gray-400 mb-1">Setor Destaque</p>
              <p className="text-sm font-bold text-amber-400">{stats.sector}</p>
            </motion.div>
          </div>
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

export default function HistoriaJapao() {
  const [selectedPeriod, setSelectedPeriod] = useState("all");

  const filteredData = selectedPeriod === "all" 
    ? timelineData 
    : timelineData.filter(item => item.period === selectedPeriod);

  return (
    <div className="min-h-screen p-6 md:p-10 relative overflow-hidden">
      {/* Animated Background Elements */}
      <motion.div
        className="absolute top-20 right-10 w-64 h-64 opacity-5"
        animate={{
          rotate: 360,
          scale: [1, 1.2, 1]
        }}
        transition={{ duration: 30, repeat: Infinity }}
      >
        <img src="https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=400" alt="Tokyo" className="w-full h-full object-cover rounded-full" />
      </motion.div>

      <div className="max-w-6xl mx-auto space-y-8 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <Badge className="bg-red-600 text-white mb-4">🇯🇵 Linha do Tempo</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            História do Japão
          </h1>
          <p className="text-gray-300 text-lg leading-relaxed max-w-4xl">
            De 1945 a 2025: 80 anos de transformação — das cinzas da guerra à liderança global em tecnologia e inovação.
          </p>
        </motion.div>

        {/* Animated Stats Overview */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-br from-red-900/40 to-amber-900/40 border border-red-700/30 backdrop-blur-sm relative overflow-hidden">
            <motion.div
              className="absolute inset-0 opacity-10"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800')",
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
              animate={{
                scale: [1, 1.1, 1],
              }}
              transition={{ duration: 20, repeat: Infinity }}
            />
            <CardContent className="p-8 relative z-10">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <motion.div 
                  className="text-center"
                  whileHover={{ scale: 1.1, y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="text-4xl font-bold text-white mb-2">2º → 3º</div>
                  <p className="text-gray-300 text-sm">Ranking Mundial<br/>(1968-2010)</p>
                </motion.div>
                <motion.div 
                  className="text-center"
                  whileHover={{ scale: 1.1, y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="text-4xl font-bold text-emerald-400 mb-2">10%</div>
                  <p className="text-gray-300 text-sm">Crescimento Médio<br/>(1955-1975)</p>
                </motion.div>
                <motion.div 
                  className="text-center"
                  whileHover={{ scale: 1.1, y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="text-4xl font-bold text-blue-400 mb-2">3.5%</div>
                  <p className="text-gray-300 text-sm">PIB em P&D<br/>(2025)</p>
                </motion.div>
                <motion.div 
                  className="text-center"
                  whileHover={{ scale: 1.1, y: -5 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <div className="text-4xl font-bold text-amber-400 mb-2">#1</div>
                  <p className="text-gray-300 text-sm">Robótica e IA<br/>Global</p>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Filter Tabs */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="flex justify-center"
        >
          <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod} className="w-full max-w-4xl">
            <TabsList className="w-full grid grid-cols-3 md:grid-cols-6 bg-white/10 p-1">
              <TabsTrigger value="all" className="data-[state=active]:bg-red-600">Todos</TabsTrigger>
              <TabsTrigger value="1945-1955" className="data-[state=active]:bg-red-600">1945-55</TabsTrigger>
              <TabsTrigger value="1955-1975" className="data-[state=active]:bg-red-600">1955-75</TabsTrigger>
              <TabsTrigger value="1975-1990" className="data-[state=active]:bg-red-600">1975-90</TabsTrigger>
              <TabsTrigger value="1990-2010" className="data-[state=active]:bg-red-600">1990-10</TabsTrigger>
              <TabsTrigger value="2010-2025" className="data-[state=active]:bg-red-600">2010-25</TabsTrigger>
            </TabsList>
          </Tabs>
        </motion.div>

        {/* Timeline Cards */}
        <div className="space-y-8">
          <AnimatePresence mode="wait">
            {filteredData.map((item, index) => (
              <TimelineCard
                key={item.period}
                {...item}
                imageUrl={timelineImages[item.period]}
                delay={0.5 + index * 0.15}
              />
            ))}
          </AnimatePresence>
        </div>

        {/* Key Factors with animated icons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-r from-indigo-900/40 to-blue-900/40 border border-indigo-700/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-white">
                Fatores-Chave do Sucesso Japonês
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  { icon: Factory, title: "Educação de Elite", description: "Investimento massivo em ensino técnico e científico.", color: "bg-amber-600" },
                  { icon: Building2, title: "Políticas Industriais", description: "MITI direcionou recursos para setores estratégicos.", color: "bg-blue-600" },
                  { icon: Rocket, title: "Cultura Kaizen", description: "Melhoria contínua como filosofia empresarial.", color: "bg-emerald-600" },
                  { icon: Cpu, title: "P&D Agressivo", description: "Um dos maiores investimentos em pesquisa do mundo.", color: "bg-red-600" }
                ].map((item, idx) => (
                  <motion.div
                    key={idx}
                    className="flex items-start gap-3"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.9 + idx * 0.1 }}
                    whileHover={{ x: 10 }}
                  >
                    <motion.div 
                      className={`w-10 h-10 rounded-lg ${item.color} flex items-center justify-center flex-shrink-0`}
                      animate={{ rotate: [0, 5, -5, 0] }}
                      transition={{ duration: 3, repeat: Infinity, delay: idx * 0.5 }}
                    >
                      <item.icon className="w-5 h-5 text-white" />
                    </motion.div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">{item.title}</h4>
                      <p className="text-gray-300 text-sm">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}