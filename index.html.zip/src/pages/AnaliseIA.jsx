import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Sparkles, 
  MessageCircle,
  Send,
  Loader2,
  TrendingUp,
  Calendar,
  BarChart3,
  Lightbulb,
  Bot
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const scenarios = [
  { id: 1, title: "Crescimento do PIB 2025-2050", icon: TrendingUp, prompt: "Projete o crescimento do PIB do Japão de 2025 a 2050, considerando tendências de envelhecimento populacional, automação e IA." },
  { id: 2, title: "Impacto da IA na Produtividade", icon: Sparkles, prompt: "Analise como a inteligência artificial pode impactar a produtividade japonesa nos próximos 25 anos." },
  { id: 3, title: "Comparação Brasil-Japão 2030", icon: BarChart3, prompt: "Compare projeções para Brasil e Japão em 2030 considerando investimentos em P&D e educação." },
  { id: 4, title: "Robótica e Envelhecimento", icon: Lightbulb, prompt: "Como a robótica avançada pode ajudar o Japão a lidar com sua população idosa até 2050?" }
];

export default function AnaliseIA() {
  const [chatMessages, setChatMessages] = useState([
    { role: "assistant", content: "Olá! 👋 Sou seu assistente de análise histórica e econômica. Pergunte-me sobre o Japão (1945-2025), modelos de crescimento endógeno, comparações com o Brasil, ou simulações futuras!" }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [scenarioResult, setScenarioResult] = useState(null);
  const [isLoadingScenario, setIsLoadingScenario] = useState(false);

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const userMessage = userInput;
    setUserInput("");
    setChatMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Você é um especialista em história econômica do Japão (1945-2025), teoria de crescimento endógeno, e análise comparativa Brasil-Japão.

Contexto:
- O Japão passou de devastação em 1945 para a 3ª maior economia mundial
- Investimento em P&D: Japão 3.5% do PIB, Brasil 1.2%
- Teoria endógena: inovação como motor interno do crescimento
- Fatores-chave: educação, P&D, spillover de conhecimento, políticas públicas

Pergunta do usuário: ${userMessage}

Responda de forma educativa, clara e objetiva em português. Use dados e exemplos quando relevante.`,
        add_context_from_internet: true
      });

      setChatMessages(prev => [...prev, { role: "assistant", content: response }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { 
        role: "assistant", 
        content: "Desculpe, ocorreu um erro ao processar sua pergunta. Tente novamente." 
      }]);
    }

    setIsLoading(false);
  };

  const handleRunScenario = async (scenario) => {
    setIsLoadingScenario(true);
    setScenarioResult(null);

    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `${scenario.prompt}

Por favor, forneça uma análise estruturada com:
1. Tendências principais (3-5 pontos)
2. Projeções numéricas aproximadas
3. Fatores de risco
4. Oportunidades

Responda em português de forma clara e educativa.`,
        add_context_from_internet: true
      });

      setScenarioResult({
        title: scenario.title,
        content: response
      });
    } catch (error) {
      setScenarioResult({
        title: scenario.title,
        content: "Erro ao gerar simulação. Tente novamente."
      });
    }

    setIsLoadingScenario(false);
  };

  return (
    <div className="min-h-screen p-6 md:p-10">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <Badge className="bg-purple-600 text-white mb-4">Inteligência Artificial</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Análise com IA
          </h1>
          <p className="text-gray-300 text-lg leading-relaxed max-w-4xl">
            Use inteligência artificial para explorar dados históricos, fazer perguntas sobre economia japonesa 
            e simular cenários futuros (2025-2050).
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Chatbot */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <Card className="bg-white/5 backdrop-blur-sm border border-white/10 h-[700px] flex flex-col">
              <CardHeader className="border-b border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center">
                    <Bot className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl text-white">Chatbot Educativo</CardTitle>
                    <p className="text-sm text-gray-400">Faça perguntas sobre o projeto</p>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                <AnimatePresence mode="popLayout">
                  {chatMessages.map((msg, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.3 }}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl p-4 ${
                          msg.role === 'user'
                            ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                            : 'bg-white/10 text-gray-100'
                        }`}
                      >
                        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {isLoading && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex justify-start"
                  >
                    <div className="bg-white/10 rounded-2xl p-4 flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
                      <span className="text-sm text-gray-300">Pensando...</span>
                    </div>
                  </motion.div>
                )}
              </CardContent>

              <div className="border-t border-white/10 p-4">
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Digite sua pergunta aqui..."
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500 min-h-[60px] resize-none"
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={isLoading || !userInput.trim()}
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 self-end"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* Scenario Simulations */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="space-y-6"
          >
            <Card className="bg-white/5 backdrop-blur-sm border border-white/10">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-600 to-orange-600 flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl text-white">Simulações de Cenários</CardTitle>
                    <p className="text-sm text-gray-400">Projeções para 2025-2050</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {scenarios.map((scenario, idx) => (
                  <motion.div
                    key={scenario.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + idx * 0.1 }}
                  >
                    <Button
                      onClick={() => handleRunScenario(scenario)}
                      disabled={isLoadingScenario}
                      variant="outline"
                      className="w-full justify-start text-left h-auto py-4 bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20"
                    >
                      <div className="flex items-center gap-3 w-full">
                        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center flex-shrink-0">
                          <scenario.icon className="w-5 h-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-white text-sm">{scenario.title}</p>
                          <p className="text-xs text-gray-400 mt-1">{scenario.prompt.slice(0, 60)}...</p>
                        </div>
                      </div>
                    </Button>
                  </motion.div>
                ))}
              </CardContent>
            </Card>

            {/* Scenario Result */}
            <AnimatePresence mode="wait">
              {isLoadingScenario && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                >
                  <Card className="bg-gradient-to-br from-blue-900/40 to-indigo-900/40 border border-blue-700/30">
                    <CardContent className="p-8 text-center">
                      <Loader2 className="w-12 h-12 animate-spin text-blue-400 mx-auto mb-4" />
                      <p className="text-white font-semibold">Gerando simulação...</p>
                      <p className="text-gray-400 text-sm mt-2">Analisando dados e tendências</p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {scenarioResult && !isLoadingScenario && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                >
                  <Card className="bg-gradient-to-br from-emerald-900/40 to-teal-900/40 border border-emerald-700/30">
                    <CardHeader>
                      <CardTitle className="text-xl text-white flex items-center gap-2">
                        <Sparkles className="w-6 h-6 text-emerald-400" />
                        {scenarioResult.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="prose prose-invert max-w-none">
                        <p className="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap">
                          {scenarioResult.content}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Quick Prompts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Card className="bg-white/5 backdrop-blur-sm border border-white/10">
            <CardHeader>
              <CardTitle className="text-xl text-white flex items-center gap-2">
                <MessageCircle className="w-6 h-6 text-amber-400" />
                Perguntas Sugeridas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-3">
                {[
                  "Por que o Japão investiu tanto em educação após 1945?",
                  "Qual o papel da cultura Kaizen no crescimento japonês?",
                  "Como o Brasil pode replicar o modelo japonês?",
                  "Quais as principais diferenças entre crescimento clássico e endógeno?",
                  "Como a demografia afeta o futuro econômico do Japão?",
                  "Qual o impacto da IA na economia japonesa até 2050?"
                ].map((question, idx) => (
                  <Button
                    key={idx}
                    variant="outline"
                    onClick={() => setUserInput(question)}
                    className="text-left h-auto py-3 bg-white/5 border-white/10 hover:bg-white/10 hover:border-purple-500/50 text-gray-300 hover:text-white justify-start"
                  >
                    <span className="text-xs">{question}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}