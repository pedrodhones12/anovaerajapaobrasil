import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  History, 
  BarChart3, 
  Sparkles, 
  Lightbulb,
  ArrowRight,
  GraduationCap,
  Factory,
  Brain,
  Globe2
} from "lucide-react";
import { motion } from "framer-motion";

const StatCard = ({ icon: Icon, title, value, subtitle, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.6 }}
  >
    <Card className={`card-hover bg-gradient-to-br ${color} border-none shadow-2xl relative overflow-hidden`}>
      <motion.div
        className="absolute inset-0 opacity-10"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 5, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }}
      />
      <CardHeader className="pb-3 relative z-10">
        <div className="flex items-center justify-between">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          >
            <Icon className="w-8 h-8 text-white/90" />
          </motion.div>
          <Badge variant="secondary" className="bg-white/20 text-white border-none">
            2025
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="relative z-10">
        <h3 className="text-3xl font-bold text-white mb-1">{value}</h3>
        <p className="text-sm text-white/80 font-semibold">{title}</p>
        <p className="text-xs text-white/60 mt-2">{subtitle}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const FeatureCard = ({ icon: Icon, title, description, link, color, delay, imageUrl }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    transition={{ delay, duration: 0.5 }}
  >
    <Link to={link}>
      <Card className="card-hover bg-white/5 backdrop-blur-sm border border-white/10 h-full group cursor-pointer overflow-hidden relative">
        {/* Animated Background Image */}
        <motion.div 
          className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500"
          style={{
            backgroundImage: `url(${imageUrl})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.8 }}
        />
        
        <CardHeader className="relative z-10">
          <motion.div 
            className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
            whileHover={{ rotate: [0, -10, 10, -10, 0] }}
            transition={{ duration: 0.5 }}
          >
            <Icon className="w-7 h-7 text-white" />
          </motion.div>
          <CardTitle className="text-white text-xl group-hover:text-red-400 transition-colors">
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="relative z-10">
          <p className="text-gray-300 text-sm leading-relaxed mb-4">{description}</p>
          <div className="flex items-center text-red-400 text-sm font-semibold group-hover:gap-3 gap-2 transition-all">
            Explorar <ArrowRight className="w-4 h-4" />
          </div>
        </CardContent>
      </Card>
    </Link>
  </motion.div>
);

const FloatingImage = ({ src, alt, delay, position }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.8 }}
    animate={{ 
      opacity: [0.3, 0.5, 0.3],
      scale: [0.8, 1, 0.8],
      y: [0, -20, 0]
    }}
    transition={{
      duration: 6,
      repeat: Infinity,
      delay: delay,
      ease: "easeInOut"
    }}
    className={`absolute ${position} pointer-events-none`}
  >
    <img src={src} alt={alt} className="w-32 h-32 object-cover rounded-2xl opacity-20" />
  </motion.div>
);

export default function Dashboard() {
  return (
    <div className="min-h-screen p-6 md:p-10 relative overflow-hidden">
      {/* Floating Background Images */}
      <FloatingImage 
        src="https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400" 
        alt="Tokyo" 
        delay={0}
        position="top-10 left-10"
      />
      <FloatingImage 
        src="https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=400" 
        alt="Tokyo Tower" 
        delay={1.5}
        position="top-40 right-20"
      />
      <FloatingImage 
        src="https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?w=400" 
        alt="Robot" 
        delay={3}
        position="bottom-40 left-20"
      />

      <div className="max-w-7xl mx-auto space-y-12 relative z-10">
        {/* Hero Section */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12 relative"
        >
          <motion.div
            animate={{ 
              scale: [1, 1.05, 1],
              rotate: [0, 2, 0]
            }}
            transition={{ 
              duration: 10, 
              repeat: Infinity,
              ease: "easeInOut" 
            }}
            className="inline-block mb-6"
          >
            <img 
              src="https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?w=800" 
              alt="Tokyo Skyline"
              className="w-full max-w-2xl h-64 object-cover rounded-3xl shadow-2xl mx-auto"
            />
          </motion.div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">A Nova Era</span>
          </h1>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Japão e Brasil
          </h2>
          <p className="text-gray-300 text-lg md:text-xl max-w-3xl mx-auto leading-relaxed">
            Uma análise profunda sobre crescimento econômico endógeno, inovação tecnológica 
            e a transformação de nações através do conhecimento.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <StatCard
            icon={Factory}
            title="PIB Japão (1945-2025)"
            value="80 Anos"
            subtitle="De destruição a 3ª maior economia"
            color="from-red-600 to-red-800"
            delay={0.1}
          />
          <StatCard
            icon={GraduationCap}
            title="Investimento P&D"
            value="3.5%"
            subtitle="Do PIB japonês em pesquisa"
            color="from-amber-600 to-amber-800"
            delay={0.2}
          />
          <StatCard
            icon={Brain}
            title="Inovação"
            value="#1"
            subtitle="Japão em robótica e IA"
            color="from-emerald-600 to-emerald-800"
            delay={0.3}
          />
          <StatCard
            icon={Globe2}
            title="Comparativo"
            value="Brasil"
            subtitle="Potencial subutilizado"
            color="from-blue-600 to-blue-800"
            delay={0.4}
          />
        </div>

        {/* Main Question with animated image */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <Card className="bg-gradient-to-r from-red-900/30 to-amber-900/30 border border-red-700/30 backdrop-blur-sm relative overflow-hidden">
            <motion.div
              className="absolute right-0 top-0 w-64 h-full opacity-10"
              animate={{ 
                x: [0, 20, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ duration: 8, repeat: Infinity }}
            >
              <img 
                src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400"
                alt="Innovation"
                className="w-full h-full object-cover"
              />
            </motion.div>
            
            <CardHeader>
              <div className="flex items-start gap-4">
                <motion.div 
                  className="w-12 h-12 rounded-full bg-gradient-to-br from-red-500 to-amber-500 flex items-center justify-center flex-shrink-0"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                >
                  <Lightbulb className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <CardTitle className="text-2xl text-white mb-3">
                    Por que a inovação é essencial para o crescimento econômico?
                  </CardTitle>
                  <p className="text-gray-200 leading-relaxed">
                    Nos <span className="font-semibold text-amber-400">modelos de crescimento endógeno</span>, 
                    a inovação é o combustível que sustenta o progresso de longo prazo. 
                    Ela aumenta a produtividade, gera conhecimento acumulado, estimula P&D e transforma setores inteiros. 
                    O Japão demonstrou esse poder: das cinzas de 1945 à liderança em tecnologia global.
                  </p>
                </div>
              </div>
            </CardHeader>
          </Card>
        </motion.div>

        {/* Features Grid */}
        <div>
          <h3 className="text-3xl font-bold text-white mb-6 text-center">
            Explore o Projeto
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              icon={TrendingUp}
              title="Teoria Endógena"
              description="Entenda os modelos que explicam como a inovação impulsiona o crescimento econômico de dentro para fora."
              link={createPageUrl("TeoriaEndogena")}
              color="from-blue-600 to-blue-800"
              imageUrl="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400"
              delay={0.6}
            />
            <FeatureCard
              icon={History}
              title="História do Japão"
              description="Linha do tempo interativa de 1945 a 2025: da reconstrução ao domínio tecnológico."
              link={createPageUrl("HistoriaJapao")}
              color="from-red-600 to-red-800"
              imageUrl="https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400"
              delay={0.7}
            />
            <FeatureCard
              icon={BarChart3}
              title="Brasil × Japão"
              description="Análise comparativa de investimento em P&D, educação, produtividade e inovação."
              link={createPageUrl("Comparativo")}
              color="from-emerald-600 to-emerald-800"
              imageUrl="https://images.unsplash.com/photo-1483058712412-4245e9b90334?w=400"
              delay={0.8}
            />
            <FeatureCard
              icon={Sparkles}
              title="Análise com IA"
              description="Chatbot educativo e simulações de cenários futuros para 2025-2050."
              link={createPageUrl("AnaliseIA")}
              color="from-purple-600 to-purple-800"
              imageUrl="https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400"
              delay={0.9}
            />
            <FeatureCard
              icon={GraduationCap}
              title="Recursos Educativos"
              description="Infográficos, mapas de calor, gráficos e materiais para download."
              link={createPageUrl("Recursos")}
              color="from-amber-600 to-amber-800"
              imageUrl="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400"
              delay={1.0}
            />
            <FeatureCard
              icon={Globe2}
              title="Visão Global"
              description="O que o mundo pode aprender com o modelo japonês de crescimento e inovação."
              link={createPageUrl("TeoriaEndogena")}
              color="from-indigo-600 to-indigo-800"
              imageUrl="https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?w=400"
              delay={1.1}
            />
          </div>
        </div>

        {/* Call to Action with animated robot image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="text-center py-12"
        >
          <Card className="bg-gradient-to-br from-red-600 to-amber-600 border-none shadow-2xl max-w-3xl mx-auto relative overflow-hidden">
            <motion.div
              className="absolute left-0 bottom-0 w-48 h-48 opacity-20"
              animate={{
                y: [0, -20, 0],
                rotate: [0, 10, 0]
              }}
              transition={{ duration: 5, repeat: Infinity }}
            >
              <img 
                src="https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=300"
                alt="Robot"
                className="w-full h-full object-cover"
              />
            </motion.div>
            
            <CardContent className="p-10 relative z-10">
              <h3 className="text-3xl font-bold text-white mb-4">
                Comece sua Jornada
              </h3>
              <p className="text-white/90 text-lg mb-6 leading-relaxed">
                Descubra como a inovação transformou o Japão e o que o Brasil 
                pode aprender para desbloquear seu verdadeiro potencial.
              </p>
              <Link to={createPageUrl("TeoriaEndogena")}>
                <Button size="lg" className="bg-white text-red-700 hover:bg-gray-100 font-bold px-8 py-6 text-lg">
                  Começar Exploração
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}