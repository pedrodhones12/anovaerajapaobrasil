import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  GraduationCap, 
  Lightbulb, 
  Factory,
  BookOpen,
  Users,
  ArrowRight,
  CheckCircle2
} from "lucide-react";
import { motion } from "framer-motion";

const FactorCard = ({ icon: Icon, title, description, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay, duration: 0.6 }}
  >
    <Card className="bg-white/5 backdrop-blur-sm border border-white/10 h-full">
      <CardHeader>
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-3`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <CardTitle className="text-white text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-300 text-sm leading-relaxed">{description}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const BenefitItem = ({ text, delay }) => (
  <motion.div
    initial={{ opacity: 0, x: -10 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay, duration: 0.4 }}
    className="flex items-start gap-3"
  >
    <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
    <p className="text-gray-200 leading-relaxed">{text}</p>
  </motion.div>
);

export default function TeoriaEndogena() {
  return (
    <div className="min-h-screen p-6 md:p-10">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <Badge className="bg-blue-600 text-white mb-4">Fundamentos Econômicos</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Teoria do Crescimento Endógeno
          </h1>
          <p className="text-gray-300 text-lg leading-relaxed max-w-4xl">
            Diferente dos modelos clássicos onde o progresso é externo, o crescimento endógeno 
            demonstra que a própria economia pode gerar seu avanço tecnológico — 
            <span className="font-semibold text-amber-400"> o crescimento vem de dentro</span>, 
            impulsionado pela inovação e capital humano.
          </p>
        </motion.div>

        {/* Main Concept */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-br from-blue-900/40 to-indigo-900/40 border border-blue-700/30 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <CardTitle className="text-2xl text-white">
                  O Motor do Crescimento
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-200 text-lg leading-relaxed">
                Nos modelos endógenos, a <span className="font-bold text-blue-300">inovação</span> é 
                vista como o principal motor do crescimento econômico de longo prazo, pois:
              </p>
              
              <div className="grid gap-3 mt-4">
                <BenefitItem 
                  text="Aumenta a produtividade dos fatores de produção (capital e trabalho)"
                  delay={0.3}
                />
                <BenefitItem 
                  text="Gera conhecimento e tecnologia que se acumulam e se espalham pela economia"
                  delay={0.4}
                />
                <BenefitItem 
                  text="Estimula o investimento em pesquisa e desenvolvimento (P&D) e em educação"
                  delay={0.5}
                />
                <BenefitItem 
                  text="Cria novos setores econômicos, transformando indústrias tradicionais"
                  delay={0.6}
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Key Factors */}
        <div>
          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="text-3xl font-bold text-white mb-6"
          >
            Fatores-Chave do Crescimento Endógeno
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FactorCard
              icon={GraduationCap}
              title="Capital Humano"
              description="Investimento em educação e qualificação da força de trabalho. Pessoas mais capacitadas geram mais inovação e produtividade."
              color="from-amber-600 to-amber-800"
              delay={0.8}
            />
            <FactorCard
              icon={Lightbulb}
              title="Pesquisa & Desenvolvimento"
              description="Empresas e governos investem em P&D para criar novas tecnologias, produtos e processos mais eficientes."
              color="from-purple-600 to-purple-800"
              delay={0.9}
            />
            <FactorCard
              icon={Factory}
              title="Infraestrutura"
              description="Sistemas de transporte, comunicação e energia que facilitam a produção e disseminação do conhecimento."
              color="from-red-600 to-red-800"
              delay={1.0}
            />
            <FactorCard
              icon={Users}
              title="Spillover de Conhecimento"
              description="O conhecimento gerado por uma empresa ou setor beneficia outros, criando efeitos multiplicadores na economia."
              color="from-emerald-600 to-emerald-800"
              delay={1.1}
            />
            <FactorCard
              icon={BookOpen}
              title="Políticas Públicas"
              description="Incentivos fiscais, proteção à propriedade intelectual e políticas industriais que favorecem a inovação."
              color="from-blue-600 to-blue-800"
              delay={1.2}
            />
            <FactorCard
              icon={TrendingUp}
              title="Competição & Empreendedorismo"
              description="Ambientes competitivos e cultura empreendedora estimulam a busca por inovações e melhorias contínuas."
              color="from-indigo-600 to-indigo-800"
              delay={1.3}
            />
          </div>
        </div>

        {/* Comparison: Classic vs Endogenous */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6">
            Modelos Clássicos vs. Endógenos
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-white/5 backdrop-blur-sm border border-white/10">
              <CardHeader>
                <CardTitle className="text-xl text-white flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-gray-600 flex items-center justify-center">
                    <span className="text-sm font-bold">1</span>
                  </div>
                  Modelos Clássicos (Solow)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-2">
                  <ArrowRight className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300 text-sm">Progresso tecnológico é <strong>externo</strong> (exógeno)</p>
                </div>
                <div className="flex items-start gap-2">
                  <ArrowRight className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300 text-sm">Crescimento de longo prazo depende de fatores fora do modelo</p>
                </div>
                <div className="flex items-start gap-2">
                  <ArrowRight className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-300 text-sm">Convergência entre países (economias pobres crescem mais rápido)</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-emerald-900/40 to-teal-900/40 border border-emerald-700/30">
              <CardHeader>
                <CardTitle className="text-xl text-white flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center">
                    <span className="text-sm font-bold">2</span>
                  </div>
                  Modelos Endógenos
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-200 text-sm">Progresso vem de <strong>dentro</strong> da economia</p>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-200 text-sm">Inovação e capital humano são motores do crescimento</p>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-200 text-sm">Países que investem em P&D crescem mais no longo prazo</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Real-World Application */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5, duration: 0.6 }}
        >
          <Card className="bg-gradient-to-r from-red-900/30 to-amber-900/30 border border-red-700/30 backdrop-blur-sm">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-amber-500 flex items-center justify-center">
                  🇯🇵
                </div>
                Aplicação Real: O Caso do Japão
              </h3>
              <p className="text-gray-200 text-lg leading-relaxed">
                O Japão é o exemplo perfeito da teoria endógena em ação. Após a devastação de 1945, 
                o país <span className="font-bold text-amber-400">investiu massivamente em educação, pesquisa e inovação</span>.
                <br/><br/>
                Resultado: tornou-se a 3ª maior economia do mundo e líder global em robótica, eletrônicos e automação.
                O crescimento não veio de recursos naturais, mas do <span className="font-bold text-red-400">capital humano e tecnologia</span>.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}