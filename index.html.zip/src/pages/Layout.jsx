
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, 
  TrendingUp, 
  History, 
  BarChart3, 
  Sparkles,
  Book,
  Menu,
  X,
  Globe
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
    description: "Visão Geral"
  },
  {
    title: "Teoria Endógena",
    url: createPageUrl("TeoriaEndogena"),
    icon: TrendingUp,
    description: "Modelos de Crescimento"
  },
  {
    title: "História do Japão",
    url: createPageUrl("HistoriaJapao"),
    icon: History,
    description: "1945-2025"
  },
  {
    title: "Brasil × Japão",
    url: createPageUrl("Comparativo"),
    icon: BarChart3,
    description: "Análise Comparativa"
  },
  {
    title: "Análise com IA",
    url: createPageUrl("AnaliseIA"),
    icon: Sparkles,
    description: "Chatbot e Simulações"
  },
  {
    title: "Recursos",
    url: createPageUrl("Recursos"),
    icon: Book,
    description: "Materiais Educativos"
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --navy-deep: #0A1F44;
          --imperial-red: #C1272D;
          --golden: #F4D03F;
          --emerald: #1B7F4F;
          --white-soft: #FAFAFA;
          --gray-elegant: #4A5568;
        }
        
        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          background: linear-gradient(135deg, #0A1F44 0%, #1a2f5f 100%);
        }
        
        .gradient-text {
          background: linear-gradient(135deg, var(--imperial-red), var(--golden));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        .card-hover {
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .card-hover:hover {
          transform: translateY(-8px);
          box-shadow: 0 20px 40px rgba(193, 39, 45, 0.15);
        }
      `}</style>
      
      <div className="min-h-screen flex w-full">
        <Sidebar className="border-r border-gray-700 bg-[#0A1F44]">
          <SidebarHeader className="border-b border-gray-700 p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-700 rounded-xl flex items-center justify-center shadow-lg">
                <Globe className="w-7 h-7 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-lg text-white">A Nova Era</h2>
                <p className="text-xs text-gray-400">Japão e Brasil</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 py-2">
                Navegação
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => {
                    const isActive = location.pathname === item.url;
                    return (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`group relative mb-2 transition-all duration-300 ${
                            isActive 
                              ? 'bg-gradient-to-r from-red-600 to-red-700 text-white shadow-lg' 
                              : 'text-gray-300 hover:bg-gray-800/50 hover:text-white'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-4 py-3 rounded-xl">
                            <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-white'}`} />
                            <div className="flex-1">
                              <span className="font-semibold text-sm">{item.title}</span>
                              <p className="text-xs opacity-70">{item.description}</p>
                            </div>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-gray-700 p-6">
            <div className="bg-gradient-to-br from-red-900/30 to-red-800/20 rounded-xl p-4 border border-red-700/30">
              <p className="text-xs text-gray-300 leading-relaxed">
                <span className="font-semibold text-red-400">Projeto Educacional</span>
                <br />
                Análise comparativa sobre inovação e crescimento econômico.
              </p>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-[#0A1F44]/80 backdrop-blur-md border-b border-gray-700/50 px-6 py-4 md:hidden sticky top-0 z-50">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-gray-800 p-2 rounded-lg transition-colors duration-200 text-white" />
              <div className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-red-500" />
                <h1 className="text-lg font-bold text-white">A Nova Era</h1>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto bg-gradient-to-br from-[#0A1F44] via-[#1a2f5f] to-[#0A1F44]">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
